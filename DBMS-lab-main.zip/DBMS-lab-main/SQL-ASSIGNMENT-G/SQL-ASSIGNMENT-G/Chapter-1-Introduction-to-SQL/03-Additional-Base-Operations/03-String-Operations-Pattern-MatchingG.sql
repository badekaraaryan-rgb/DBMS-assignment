

USE company;

-- ============================================
-- 1. LIKE OPERATOR: Basic Pattern Matching
-- ============================================


SELECT * FROM employees WHERE first_name LIKE 'J%';

-- ============================================
-- 2. PATTERN MATCHING: Starts With
-- ============================================
SELECT first_name FROM employees WHERE first_name LIKE 'J%';

SELECT first_name, last_name FROM employees WHERE last_name LIKE 'D%';

SELECT email FROM employees WHERE email LIKE 'john%';

-- ============================================
-- 3. PATTERN MATCHING: Ends With
-- ============================================
SELECT first_name, last_name FROM employees WHERE last_name LIKE '%son';

SELECT email FROM employees WHERE email LIKE '%.com';

SELECT DISTINCT department FROM employees WHERE department LIKE '%s';

-- ============================================
-- 4. PATTERN MATCHING: Contains (Middle)
-- ============================================
SELECT first_name FROM employees WHERE first_name LIKE '%oh%';

-- Find all emails containing 'email'
SELECT email FROM employees WHERE email LIKE '%email%';

-- ============================================
-- 5. SINGLE CHARACTER WILDCARD: _
-- ============================================

SELECT first_name FROM employees WHERE first_name LIKE 'B_b';

SELECT first_name FROM employees WHERE first_name LIKE 'J___';

SELECT email FROM employees WHERE email LIKE '____%@email.com';

-- ============================================
-- 6. COMBINING WILDCARDS
-- ============================================
SELECT first_name FROM employees WHERE first_name LIKE '_a%';

SELECT email FROM employees WHERE email LIKE '%j%@%.com';

-- ============================================
-- 7. NOT LIKE: Negative Pattern Matching
-- ============================================
SELECT first_name FROM employees WHERE first_name NOT LIKE 'J%';

SELECT first_name, department FROM employees WHERE department NOT LIKE '%IT%';

-- ============================================
-- 8. CASE-SENSITIVE PATTERN MATCHING
-- ============================================
SELECT first_name FROM employees WHERE first_name LIKE 'john';  -- Matches 'John'

SELECT first_name FROM employees WHERE first_name LIKE BINARY 'john';  -- Matches only 'john'



SELECT first_name, LENGTH(first_name) AS name_length FROM employees;

SELECT UPPER(first_name) AS uppercase_name FROM employees;

SELECT LOWER(first_name) AS lowercase_name FROM employees;

SELECT first_name, SUBSTRING(first_name, 1, 3) AS first_three FROM employees;

SELECT CONCAT(first_name, ' ', last_name) AS full_name FROM employees;

SELECT CONCAT_WS(' - ', first_name, last_name, email) FROM employees;
SELECT TRIM('  John  ') AS trimmed_name;

SELECT first_name, REPLACE(first_name, 'o', '0') AS replaced FROM employees;

SELECT REVERSE(first_name) AS reversed FROM employees;

-- ============================================
-- 11. COMBINING PATTERN MATCHING WITH FUNCTIONS
-- ============================================

SELECT * FROM employees WHERE LOWER(first_name) LIKE 'j%';

SELECT * FROM employees 
WHERE email LIKE CONCAT('%', LOWER(first_name), '%');

SELECT first_name FROM employees 
WHERE first_name LIKE 'A%' AND LENGTH(first_name) > 5;

-- ============================================
-- 12. PRACTICAL EXAMPLES
-- ============================================

SELECT * FROM employees
WHERE first_name LIKE '%ar%' OR last_name LIKE '%ar%';

SELECT email FROM employees
WHERE email NOT LIKE '%@%.%';

SELECT first_name, email
FROM employees
WHERE email LIKE '%@gmail.com' OR email LIKE '%@yahoo.com';

SELECT DISTINCT department FROM employees
WHERE department LIKE 'S%' OR department LIKE '%T%';

SELECT first_name, email, salary
FROM employees
WHERE (first_name LIKE 'J%' OR last_name LIKE '%son')
  AND salary > 65000;

