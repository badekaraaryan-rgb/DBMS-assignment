

USE company;

-- ============================================
-- 1. BASIC ORDER BY: Single Column ASC (Default)
-- ============================================
SELECT first_name, salary FROM employees ORDER BY first_name;

SELECT first_name, salary FROM employees ORDER BY first_name ASC;

-- ============================================
-- 2. ORDER BY: Descending Order (DESC)
-- ============================================
SELECT first_name, salary FROM employees ORDER BY salary DESC;

SELECT first_name, last_name FROM employees ORDER BY last_name DESC;

-- ============================================
-- 3. ORDER BY: Multiple Columns
-- ============================================
SELECT first_name, department, salary FROM employees
ORDER BY department ASC, salary DESC;

SELECT first_name, salary FROM employees
ORDER BY salary DESC, first_name ASC;

-- ============================================
-- 4. ORDER BY: Using Column Position
-- ============================================
SELECT first_name, salary, department FROM employees ORDER BY 2 DESC;

SELECT first_name, salary, department FROM employees ORDER BY 1 ASC, 3 ASC;

-- ============================================
-- 5. ORDER BY: Using Column Alias
-- ============================================
SELECT 
    first_name,
    salary,
    salary * 12 AS annual_salary
FROM employees
ORDER BY annual_salary DESC;

SELECT 
    first_name AS name,
    salary AS monthly_pay,
    salary * 12 AS annual_salary
FROM employees
ORDER BY annual_salary DESC;

-- ============================================
-- 6. ORDER BY: String/Text Columns
-- ============================================
SELECT first_name FROM employees ORDER BY first_name ASC;

SELECT first_name FROM employees ORDER BY first_name DESC;

SELECT first_name, LENGTH(first_name) AS name_length FROM employees
ORDER BY LENGTH(first_name) DESC;

-- ============================================
-- 7. ORDER BY: Date Columns
-- ============================================
SELECT first_name, hire_date FROM employees ORDER BY hire_date DESC;

SELECT first_name, hire_date FROM employees ORDER BY hire_date ASC;
SELECT first_name, hire_date,
       YEAR(CURDATE()) - YEAR(hire_date) AS years_of_service
FROM employees
ORDER BY hire_date DESC;

-- ============================================
-- 8. ORDER BY: Numeric Columns
-- ============================================
SELECT first_name, salary FROM employees ORDER BY salary DESC;

SELECT first_name, salary FROM employees ORDER BY salary ASC;

-- ============================================
-- 9. ORDER BY: NULL VALUES
-- ============================================
SELECT first_name, email FROM employees ORDER BY email ASC;

SELECT first_name, email FROM employees ORDER BY email DESC;

-- ============================================
-- 10. ORDER BY: WITH WHERE CLAUSE
-- ============================================
SELECT first_name, salary, department FROM employees
WHERE salary > 65000
ORDER BY salary DESC;

SELECT first_name, last_name, salary FROM employees
WHERE department = 'IT'
ORDER BY first_name ASC;

-- ============================================
-- 11. ORDER BY: LIMIT for Top/Bottom Results
-- ============================================
SELECT first_name, salary FROM employees
ORDER BY salary DESC
LIMIT 5;

SELECT first_name, hire_date FROM employees
ORDER BY hire_date DESC
LIMIT 3;

SELECT first_name, salary FROM employees
ORDER BY salary ASC
LIMIT 3;

-- ============================================
-- 12. ORDER BY: OFFSET for Pagination
-- ============================================
SELECT first_name, salary FROM employees
ORDER BY salary DESC
LIMIT 3 OFFSET 2;


SELECT first_name, salary FROM employees
ORDER BY salary DESC
LIMIT 2, 3;   -- Skip 2, get 3

-- ============================================
-- 13. ORDER BY: CASE for Custom Sorting
-- ============================================
SELECT first_name, department FROM employees
ORDER BY CASE 
    WHEN department = 'Sales' THEN 1
    WHEN department = 'IT' THEN 2
    WHEN department = 'HR' THEN 3
    ELSE 4
END;

-- ============================================
-- 14. ORDER BY: Mathematical Expressions
-- ============================================
SELECT first_name, salary FROM employees
ORDER BY ABS(salary - (SELECT AVG(salary) FROM employees)) ASC;

SELECT first_name, salary,
       salary * 0.1 AS bonus_10_percent
FROM employees
ORDER BY salary * 0.1 DESC;

-- ============================================
-- 15. PRACTICAL EXAMPLES
-- ============================================

SELECT 
    first_name,
    department,
    salary,
    salary * 12 AS annual_salary
FROM employees
ORDER BY department ASC, salary DESC;

SELECT 
    first_name,
    hire_date,
    YEAR(CURDATE()) - YEAR(hire_date) AS years_employed
FROM employees
ORDER BY hire_date ASC;

SELECT 
    first_name,
    salary,
    ROW_NUMBER() OVER (ORDER BY salary DESC) AS salary_rank
FROM employees;

SELECT 
    first_name,
    department,
    salary,
    email
FROM employees
WHERE salary > 60000
ORDER BY department ASC, salary DESC, first_name ASC;

