
USE company;

-- ============================================
-- 1. COMPARISON PREDICATES
-- ============================================
SELECT * FROM employees WHERE department = 'Sales';

SELECT * FROM employees WHERE department != 'IT';

SELECT * FROM employees WHERE salary > 70000;

SELECT * FROM employees WHERE salary < 70000;

SELECT * FROM employees WHERE salary >= 70000;

SELECT * FROM employees WHERE salary <= 70000;

-- ============================================
-- 2. LOGICAL CONNECTIVES: AND
-- ============================================
SELECT * FROM employees
WHERE salary > 70000 AND department = 'Sales';

SELECT * FROM employees
WHERE salary > 60000 AND salary < 80000;

SELECT * FROM employees
WHERE department = 'IT' AND salary >= 70000;

-- ============================================
-- 3. LOGICAL CONNECTIVES: OR
-- ============================================
SELECT * FROM employees
WHERE department = 'Sales' OR department = 'IT';

SELECT * FROM employees
WHERE salary < 60000 OR salary > 80000;

SELECT * FROM employees
WHERE first_name = 'John' OR first_name = 'Jane';

-- ============================================
-- 4. LOGICAL CONNECTIVES: NOT
-- ============================================
SELECT * FROM employees
WHERE NOT department = 'HR';

SELECT * FROM employees
WHERE NOT (salary < 70000);   -- salary >= 70000

SELECT * FROM employees
WHERE NOT (department = 'IT' AND salary > 75000);

-- ============================================
-- 5. COMBINING AND, OR, NOT (with Parentheses)
-- ============================================
SELECT * FROM employees
WHERE (department = 'Sales' AND salary > 70000) 
   OR (department = 'IT' AND salary > 75000);

SELECT * FROM employees
WHERE salary > 70000 AND (department = 'IT' OR department = 'HR');

SELECT * FROM employees
WHERE NOT (department = 'Sales' AND salary < 70000);

-- ============================================
-- 6. BETWEEN: Range Filter
-- ============================================
SELECT * FROM employees
WHERE salary BETWEEN 60000 AND 80000;

SELECT * FROM employees
WHERE salary NOT BETWEEN 60000 AND 80000;

SELECT * FROM employees
WHERE hire_date BETWEEN '2022-01-01' AND '2023-06-30';

-- ============================================
-- 7. IN: Set Membership
-- ============================================
SELECT * FROM employees
WHERE department IN ('Sales', 'IT', 'HR');

-- Not in any value
SELECT * FROM employees
WHERE department NOT IN ('Sales', 'IT');

-- IN with numbers
SELECT * FROM employees
WHERE emp_id IN (1, 3, 5);

SELECT * FROM employees
WHERE first_name LIKE 'J%';

SELECT * FROM employees
WHERE last_name LIKE '%n';

SELECT * FROM employees
WHERE first_name LIKE '%oh%';

SELECT * FROM employees
WHERE first_name LIKE 'B_b';

SELECT * FROM employees
WHERE first_name LIKE 'john';  -- Matches 'John'

-- ============================================
-- 9. IS NULL AND IS NOT NULL
-- ============================================
SELECT * FROM employees
WHERE email IS NULL;

SELECT * FROM employees
WHERE email IS NOT NULL;

SELECT * FROM employees
WHERE department IS NOT NULL AND salary > 70000;

-- ============================================
-- 10. COMPLEX WHERE CLAUSE EXAMPLES
-- ============================================
SELECT * FROM employees
WHERE (department = 'Sales' OR department = 'IT')
  AND salary > 65000;

SELECT * FROM employees
WHERE hire_date > '2023-01-01'
  AND department != 'HR';
SELECT * FROM employees
WHERE department NOT IN ('IT', 'Sales')
  AND salary BETWEEN 60000 AND 80000;

SELECT * FROM employees
WHERE first_name LIKE 'J%'
  AND salary > 75000;

SELECT * FROM employees
WHERE department = 'Sales' 
   OR (department = 'IT' AND salary > 70000);
