
USE company;

-- ============================================
-- 1. SINGLE TABLE QUERY (Most Common)
-- ============================================
SELECT * FROM employees;

SELECT first_name, salary FROM employees;

SELECT emp_id, first_name, salary FROM employees
WHERE salary > 70000;

-- ============================================
-- 2. CARTESIAN PRODUCT: FROM Multiple Tables
-- ============================================


CREATE TABLE IF NOT EXISTS departments (
    dept_id INT PRIMARY KEY,
    dept_name VARCHAR(50),
    location VARCHAR(50)
);

INSERT INTO departments (dept_id, dept_name, location) VALUES
(1, 'Sales', 'New York'),
(2, 'IT', 'San Francisco'),
(3, 'HR', 'Boston');


SELECT e.emp_id, e.first_name, d.dept_id, d.dept_name
FROM employees e, departments d;

-- ============================================
-- 3. TABLE ALIASES (Shortening Table Names)
-- ============================================
SELECT e.emp_id, e.first_name, e.salary
FROM employees AS e;

SELECT e.emp_id, e.first_name, e.salary
FROM employees e;

SELECT emp.emp_id, emp.first_name, dept.dept_name
FROM employees emp, departments dept;

-- ============================================
-- 4. COLUMN ALIASES IN FROM CLAUSE
-- ============================================
SELECT 
    e.emp_id AS 'Employee ID',
    e.first_name AS 'Name',
    e.salary AS 'Salary'
FROM employees e;

-- ============================================
-- 5. MULTIPLE TABLES WITH CONDITIONS
-- ============================================
SELECT e.first_name, e.salary, d.dept_name
FROM employees e, departments d
WHERE e.department = d.dept_name;

-- ============================================
-- 6. FILTERING WITH FROM
-- ============================================
SELECT e.first_name, e.salary, d.location
FROM employees e, departments d
WHERE e.department = d.dept_name
  AND e.salary > 70000;

-- ============================================
-- 7. DERIVED TABLES (Subquery in FROM Clause)
-- ============================================
SELECT emp_id, full_name, salary
FROM (
    SELECT emp_id, CONCAT(first_name, ' ', last_name) AS full_name, salary
    FROM employees
) AS emp_derived
WHERE salary > 70000;

-- ============================================
-- 8. FROM WITH ORDER BY (Introduced Here)
-- ============================================
SELECT e.first_name, e.salary, e.department
FROM employees e
WHERE e.department = 'IT'
ORDER BY e.salary DESC;


-- Example showing this order:
SELECT first_name, salary
FROM employees
WHERE salary > 65000
ORDER BY salary DESC
LIMIT 3;




SELECT emp_id, first_name, email
FROM employees;

SELECT first_name, salary, department
FROM employees
WHERE department = 'Sales';

SELECT 
    e.first_name,
    e.salary,
    d.dept_name,
    d.location
FROM employees e, departments d
WHERE e.department = d.dept_name;

SELECT 
    avg_salary_by_dept
FROM (
    SELECT AVG(salary) AS avg_salary_by_dept
    FROM employees
) AS salary_stats;

