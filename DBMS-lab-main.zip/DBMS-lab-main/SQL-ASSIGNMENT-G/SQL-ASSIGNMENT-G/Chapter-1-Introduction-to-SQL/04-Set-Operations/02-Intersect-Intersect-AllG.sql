

USE company;

-- ============================================
-- 1. SIMULATING INTERSECT Using INNER JOIN
-- ============================================

CREATE TABLE IF NOT EXISTS employees_sales (
    emp_id INT,
    name VARCHAR(50)
);

CREATE TABLE IF NOT EXISTS employees_it (
    emp_id INT,
    name VARCHAR(50)
);

INSERT INTO employees_sales VALUES
(1, 'Alice'),
(2, 'Bob'),
(3, 'Charlie'),
(4, 'Diana');

INSERT INTO employees_it VALUES
(2, 'Bob'),
(4, 'Diana'),
(5, 'Eve'),
(6, 'Frank');

SELECT DISTINCT s.name
FROM employees_sales s
INNER JOIN employees_it i ON s.name = i.name;

-- ============================================
-- 2. SIMULATING INTERSECT Using EXISTS
-- ============================================
SELECT DISTINCT s.name
FROM employees_sales s
WHERE EXISTS (
    SELECT 1 FROM employees_it i WHERE i.name = s.name
);

-- ============================================
-- 3. INTERSECT: Multiple Columns
-- ============================================
CREATE TABLE IF NOT EXISTS product_catalog_2023 (
    product_id INT,
    product_name VARCHAR(50),
    category VARCHAR(50)
);

CREATE TABLE IF NOT EXISTS inventory_2023 (
    product_id INT,
    product_name VARCHAR(50),
    category VARCHAR(50)
);

INSERT INTO product_catalog_2023 VALUES
(1, 'Laptop', 'Electronics'),
(2, 'Phone', 'Electronics'),
(3, 'Desk', 'Furniture');

INSERT INTO inventory_2023 VALUES
(2, 'Phone', 'Electronics'),
(3, 'Desk', 'Furniture'),
(4, 'Chair', 'Furniture');

SELECT product_id, product_name, category FROM product_catalog_2023
INTERSECT
SELECT product_id, product_name, category FROM inventory_2023;

SELECT DISTINCT p.product_id, p.product_name, p.category
FROM product_catalog_2023 p
INNER JOIN inventory_2023 i 
    ON p.product_id = i.product_id
    AND p.product_name = i.product_name
    AND p.category = i.category;

-- ============================================
-- 4. INTERSECT: Common Values
-- ============================================
SELECT emp_id FROM employees_sales
INTERSECT
SELECT emp_id FROM employees_it;

SELECT DISTINCT s.emp_id
FROM employees_sales s
WHERE EXISTS (
    SELECT 1 FROM employees_it i WHERE i.emp_id = s.emp_id
);

-- ============================================
-- 5. PRACTICAL EXAMPLES
-- ============================================


CREATE TABLE IF NOT EXISTS students_course_a (
    student_id INT,
    student_name VARCHAR(50)
);

CREATE TABLE IF NOT EXISTS students_course_b (
    student_id INT,
    student_name VARCHAR(50)
);

INSERT INTO students_course_a VALUES
(1, 'Alice'),
(2, 'Bob'),
(3, 'Charlie');

INSERT INTO students_course_b VALUES
(2, 'Bob'),
(3, 'Charlie'),
(4, 'Diana');

SELECT DISTINCT s1.student_name
FROM students_course_a s1
INNER JOIN students_course_b s2 ON s1.student_name = s2.student_name;


SELECT DISTINCT name FROM employees_sales
WHERE name IN (SELECT name FROM employees_it);

SELECT s.name
FROM employees_sales s
INNER JOIN employees_it i ON s.name = i.name;


CREATE TABLE IF NOT EXISTS test_a (
    value VARCHAR(50)
);

CREATE TABLE IF NOT EXISTS test_b (
    value VARCHAR(50)
);

INSERT INTO test_a VALUES ('Apple'), ('Apple'), ('Banana'), ('Cherry');
INSERT INTO test_b VALUES ('Apple'), ('Banana'), ('Banana'), ('Date');SELECT DISTINCT value FROM test_a
WHERE value IN (SELECT value FROM test_b);

SELECT a.value
FROM test_a a
INNER JOIN test_b b ON a.value = b.value;
