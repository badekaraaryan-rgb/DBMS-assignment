USE company;

CREATE TABLE IF NOT EXISTS sales_employees (
    emp_id INT,
    name VARCHAR(50),
    salary DECIMAL(10,2)
);

CREATE TABLE IF NOT EXISTS it_employees (
    emp_id INT,
    name VARCHAR(50),
    salary DECIMAL(10,2)
);

INSERT INTO sales_employees VALUES
(1, 'John Doe', 75000),
(2, 'Jane Smith', 82000),
(3, 'Bob Johnson', 60000);

INSERT INTO it_employees VALUES
(4, 'Alice Williams', 72000),
(5, 'Mike Brown', 68000),
(1, 'John Doe', 75000);  

-- ============================================
-- 1. UNION: Combine Without Duplicates
-- ============================================
SELECT name, salary FROM sales_employees
UNION
SELECT name, salary FROM it_employees;

-- ============================================
-- 2. UNION ALL: Combine With Duplicates
-- ============================================
SELECT name, salary FROM sales_employees
UNION ALL
SELECT name, salary FROM it_employees;

-- ============================================
-- 3. UNION: Different Tables, Same Schema
-- ============================================

CREATE TABLE IF NOT EXISTS employees_2022 (
    emp_id INT,
    name VARCHAR(50)
);

CREATE TABLE IF NOT EXISTS employees_2023 (
    emp_id INT,
    name VARCHAR(50)
);

INSERT INTO employees_2022 VALUES
(1, 'Alice'), (2, 'Bob'), (3, 'Charlie');

INSERT INTO employees_2023 VALUES
(2, 'Bob'), (3, 'Charlie'), (4, 'Diana');

SELECT name FROM employees_2022
UNION
SELECT name FROM employees_2023;

SELECT name FROM employees_2022
UNION ALL
SELECT name FROM employees_2023;

-- ============================================
-- 4. UNION: Multiple Tables
-- ============================================
SELECT name FROM employees_2022
UNION
SELECT name FROM employees_2023
UNION
SELECT name FROM sales_employees;

-- ============================================
-- 5. UNION: With WHERE Clause
-- ============================================
SELECT name, salary FROM sales_employees WHERE salary > 70000
UNION
SELECT name, salary FROM it_employees WHERE salary > 70000;

-- ============================================
-- 6. UNION: With ORDER BY
-- ============================================
SELECT name FROM sales_employees
UNION
SELECT name FROM it_employees
ORDER BY name ASC;

SELECT name, salary FROM sales_employees
UNION
SELECT name, salary FROM it_employees
ORDER BY salary DESC;

-- ============================================
-- 7. UNION: With Aliases
-- ============================================
SELECT name AS employee_name, salary, 'Sales' AS department FROM sales_employees
UNION
SELECT name AS employee_name, salary, 'IT' AS department FROM it_employees
ORDER BY employee_name;

-- ============================================
-- 8. UNION: Rules and Constraints
-- ============================================
SELECT emp_id, name FROM sales_employees
UNION
SELECT emp_id, CONCAT('Mr. ', name) FROM it_employees;

-- ============================================
-- 9. UNION ALL: Performance Advantage
-- ============================================

SELECT name FROM sales_employees
UNION ALL
SELECT name FROM it_employees;

-- ============================================
-- 10. PRACTICAL EXAMPLES
-- ============================================


SELECT 'Q1 2023' AS quarter, SUM(amount) AS revenue FROM sales_2023_q1
UNION
SELECT 'Q2 2023' AS quarter, SUM(amount) AS revenue FROM sales_2023_q2
UNION
SELECT 'Q3 2023' AS quarter, SUM(amount) AS revenue FROM sales_2023_q3;

-- ============================================
-- 11. UNION vs JOIN
-- ============================================
SELECT name FROM sales_employees
UNION
SELECT name FROM it_employees;
