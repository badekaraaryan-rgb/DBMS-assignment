

USE company;

-- ============================================
-- 1. SIMULATING EXCEPT Using LEFT JOIN
-- ============================================

CREATE TABLE IF NOT EXISTS sales_team (
    emp_id INT,
    name VARCHAR(50)
);

CREATE TABLE IF NOT EXISTS it_team (
    emp_id INT,
    name VARCHAR(50)
);

INSERT INTO sales_team VALUES
(1, 'Alice'),
(2, 'Bob'),
(3, 'Charlie'),
(4, 'Diana');

INSERT INTO it_team VALUES
(2, 'Bob'),
(4, 'Diana'),
(5, 'Eve');

SELECT DISTINCT s.name
FROM sales_team s
LEFT JOIN it_team i ON s.name = i.name
WHERE i.name IS NULL;

-- ============================================
-- 2. SIMULATING EXCEPT Using NOT EXISTS
-- ============================================
SELECT DISTINCT s.name
FROM sales_team s
WHERE NOT EXISTS (
    SELECT 1 FROM it_team i WHERE i.name = s.name
);

-- ============================================
-- 3. SIMULATING EXCEPT Using NOT IN
-- ============================================
SELECT DISTINCT name
FROM sales_team
WHERE name NOT IN (SELECT name FROM it_team);

-- ============================================
-- 4. EXCEPT: Multiple Columns
-- ============================================
CREATE TABLE IF NOT EXISTS product_catalog (
    product_id INT,
    product_name VARCHAR(50),
    price DECIMAL(10,2)
);

CREATE TABLE IF NOT EXISTS discontinued_products (
    product_id INT,
    product_name VARCHAR(50),
    price DECIMAL(10,2)
);

INSERT INTO product_catalog VALUES
(1, 'Laptop', 1000.00),
(2, 'Phone', 800.00),
(3, 'Tablet', 500.00),
(4, 'Monitor', 300.00);

INSERT INTO discontinued_products VALUES
(2, 'Phone', 800.00),
(4, 'Monitor', 300.00);

SELECT product_id, product_name, price FROM product_catalog
EXCEPT
SELECT product_id, product_name, price FROM discontinued_products;

SELECT DISTINCT p.product_id, p.product_name, p.price
FROM product_catalog p
LEFT JOIN discontinued_products d 
    ON p.product_id = d.product_id
    AND p.product_name = d.product_name
    AND p.price = d.price
WHERE d.product_id IS NULL;

-- ============================================
-- 5. EXCEPT: Simple Difference
-- ============================================
SELECT emp_id FROM sales_team
EXCEPT
SELECT emp_id FROM it_team;

SELECT DISTINCT s.emp_id
FROM sales_team s
LEFT JOIN it_team i ON s.emp_id = i.emp_id
WHERE i.emp_id IS NULL;

-- ============================================
-- 6. PRACTICAL EXAMPLES
-- ============================================



CREATE TABLE IF NOT EXISTS all_products (
    product_id INT,
    product_name VARCHAR(50)
);

CREATE TABLE IF NOT EXISTS ordered_products (
    product_id INT,
    product_name VARCHAR(50)
);

INSERT INTO all_products VALUES
(1, 'Apple'),
(2, 'Banana'),
(3, 'Cherry'),
(4, 'Date');

INSERT INTO ordered_products VALUES
(1, 'Apple'),
(3, 'Cherry');

SELECT p.product_id, p.product_name
FROM all_products p
LEFT JOIN ordered_products o ON p.product_id = o.product_id
WHERE o.product_id IS NULL;

CREATE TABLE IF NOT EXISTS registered_students (
    student_id INT,
    name VARCHAR(50)
);

CREATE TABLE IF NOT EXISTS attending_students (
    student_id INT,
    name VARCHAR(50)
);

INSERT INTO registered_students VALUES
(1, 'Alice'),
(2, 'Bob'),
(3, 'Charlie'),
(4, 'Diana');

INSERT INTO attending_students VALUES
(1, 'Alice'),
(3, 'Charlie'),
(4, 'Diana');

SELECT DISTINCT r.name
FROM registered_students r
WHERE r.name NOT IN (SELECT name FROM attending_students);

-- ============================================
-- 7. EXCEPT ALL: With Duplicates
-- ============================================

CREATE TABLE IF NOT EXISTS set_a (
    value VARCHAR(50)
);

CREATE TABLE IF NOT EXISTS set_b (
    value VARCHAR(50)
);

INSERT INTO set_a VALUES ('Apple'), ('Apple'), ('Banana'), ('Cherry');
INSERT INTO set_b VALUES ('Apple'), ('Banana');

SELECT DISTINCT value FROM set_a
WHERE value NOT IN (SELECT value FROM set_b);

SELECT a.value
FROM set_a a
LEFT JOIN set_b b ON a.value = b.value
WHERE b.value IS NULL;

-- ============================================
-- 8. COMBINATION: EXCEPT with UNION
-- ============================================
SELECT name FROM sales_team
EXCEPT
SELECT name FROM it_team
UNION
SELECT name FROM it_team
EXCEPT
SELECT name FROM sales_team;

SELECT s.name FROM sales_team s
WHERE s.name NOT IN (SELECT i.name FROM it_team i)
UNION
SELECT i.name FROM it_team i
WHERE i.name NOT IN (SELECT s.name FROM sales_team s);

-- ============================================
-- 9. EXCEPT vs WHERE NOT IN
-- ============================================

SELECT DISTINCT name FROM sales_team
WHERE name NOT IN (SELECT name FROM it_team);

SELECT DISTINCT s.name FROM sales_team s
WHERE NOT EXISTS (SELECT 1 FROM it_team i WHERE i.name = s.name);

SELECT DISTINCT s.name FROM sales_team s
LEFT JOIN it_team i ON s.name = i.name
WHERE i.name IS NULL;
