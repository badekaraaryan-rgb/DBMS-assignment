
USE company;


-- This prevents errors if the table doesn't exist
DROP TABLE IF EXISTS temp_table;

-- Drop multiple tables
DROP TABLE IF EXISTS table1, table2, table3;


-- Option 1: Drop in correct order (child tables first, then parent)
DROP TABLE IF EXISTS orders;          -- Child table
DROP TABLE IF EXISTS order_items;    -- Child table
DROP TABLE IF EXISTS customers;      -- Parent table

-- Option 2: Temporarily disable foreign key checks (use with caution)



-- TRUNCATE example:
TRUNCATE TABLE employees;   -- Clears all data, keeps structure

-- Drop example:

DROP TABLE IF EXISTS employees;
DROP TABLE IF EXISTS customers;
DROP TABLE IF EXISTS orders;

CREATE TABLE employees_backup AS
SELECT * FROM employees;
