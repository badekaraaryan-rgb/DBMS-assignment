

USE company;

-- ============================================
-- 1. BASIC HAVING: Filter Groups
-- ============================================
SELECT 
    department,
    COUNT(*) AS employee_count
FROM employees
GROUP BY department
HAVING COUNT(*) > 2;

SELECT 
    department,
    AVG(salary) AS avg_salary
FROM employees
GROUP BY department
HAVING AVG(salary) > 70000;


SELECT 
    department,
    COUNT(*) AS count
FROM employees
WHERE salary > 65000
GROUP BY department;

SELECT 
    department,
    COUNT(*) AS count
FROM employees
GROUP BY department
HAVING COUNT(*) > 1;

SELECT 
    department,
    COUNT(*) AS count
FROM employees
WHERE salary > 65000
GROUP BY department
HAVING COUNT(*) >= 2;

-- ============================================
-- 3. HAVING WITH MULTIPLE CONDITIONS
-- ============================================
SELECT 
    department,
    COUNT(*) AS emp_count,
    AVG(salary) AS avg_salary
FROM employees
GROUP BY department
HAVING COUNT(*) > 2 AND AVG(salary) > 70000;

-- ============================================
-- 4. HAVING WITH AGGREGATE FUNCTIONS
-- ============================================
SELECT 
    department,
    MAX(salary) AS highest_salary
FROM employees
GROUP BY department
HAVING MAX(salary) > 80000;

SELECT 
    department,
    MIN(salary) AS lowest,
    MAX(salary) AS highest,
    MAX(salary) - MIN(salary) AS range
FROM employees
GROUP BY department
HAVING MAX(salary) - MIN(salary) > 20000;

-- ============================================
-- 5. HAVING WITH ORDER BY
-- ============================================
SELECT 
    department,
    COUNT(*) AS employee_count,
    AVG(salary) AS avg_salary
FROM employees
GROUP BY department
HAVING COUNT(*) > 1
ORDER BY employee_count DESC;

SELECT 
    department,
    SUM(salary) AS total_payroll
FROM employees
GROUP BY department
HAVING SUM(salary) > 150000
ORDER BY total_payroll DESC;

-- ============================================
-- 6. PRACTICAL EXAMPLES
-- ============================================

SELECT 
    department,
    COUNT(*) AS employees,
    SUM(salary) AS total_payroll
FROM employees
GROUP BY department
HAVING SUM(salary) < 200000
ORDER BY total_payroll;

SELECT 
    department,
    COUNT(*) AS count,
    ROUND(AVG(salary), 2) AS avg_salary,
    STDDEV_POP(salary) AS salary_stddev
FROM employees
GROUP BY department
HAVING STDDEV_POP(salary) > 5000;

SELECT 
    department,
    COUNT(*) AS current_staff
FROM employees
GROUP BY department
HAVING COUNT(*) < 3
ORDER BY current_staff;
SELECT 
    department,
    COUNT(*) AS employees,
    SUM(salary) AS total_cost,
    ROUND(AVG(salary), 2) AS avg_cost
FROM employees
GROUP BY department
HAVING SUM(salary) > 250000
ORDER BY total_cost DESC;

-- ============================================
-- ============================================
-- Multiple conditions with OR
SELECT 
    department,
    COUNT(*) AS count,
    AVG(salary) AS avg_sal
FROM employees
GROUP BY department
HAVING COUNT(*) > 3 OR AVG(salary) > 80000;

SELECT 
    department,
    SUM(salary) AS total
FROM employees
GROUP BY department
HAVING SUM(salary) NOT BETWEEN 100000 AND 200000;

-- ============================================
-- 8. HAVING vs WHERE: Performance
-- ============================================

SELECT 
    department,
    COUNT(*) AS count
FROM employees
GROUP BY department
HAVING AVG(salary) > 70000;

SELECT 
    department,
    COUNT(*) AS count
FROM employees
WHERE salary > 70000
GROUP BY department;

