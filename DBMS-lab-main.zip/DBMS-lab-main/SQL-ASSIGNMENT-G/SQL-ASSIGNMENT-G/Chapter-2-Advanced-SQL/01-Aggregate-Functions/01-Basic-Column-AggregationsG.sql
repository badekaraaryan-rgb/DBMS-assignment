

USE company;

-- Setup
CREATE TABLE IF NOT EXISTS employees (
    emp_id INT PRIMARY KEY,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    salary DECIMAL(10,2),
    department VARCHAR(50),
    hire_date DATE
);

INSERT INTO employees VALUES
(1, 'Alice', 'Smith', 90000, 'Management', '2021-01-15'),
(2, 'Bob', 'Johnson', 75000, 'Sales', '2022-03-20'),
(3, 'Charlie', 'Brown', 70000, 'Sales', '2022-06-10'),
(4, 'Diana', 'Davis', 65000, 'HR', '2023-02-01'),
(5, 'Eve', 'Wilson', 62000, 'IT', '2023-05-12'),
(6, 'Frank', 'Miller', 72000, 'IT', '2023-07-01');

-- ============================================
-- 1. COUNT: Count Number of Rows
-- ============================================
SELECT COUNT(*) AS total_employees FROM employees;

SELECT COUNT(emp_id) AS total_employees FROM employees;

SELECT COUNT(DISTINCT department) AS unique_departments FROM employees;

-- ============================================
-- 2. SUM: Sum of Column Values
-- ============================================
SELECT SUM(salary) AS total_salary FROM employees;

SELECT SUM(salary) AS sales_payroll FROM employees WHERE department = 'Sales';

-- ============================================
-- 3. AVG: Average Value
-- ============================================
SELECT AVG(salary) AS avg_salary FROM employees;

-- Average salary by department (will use GROUP BY)
SELECT department, AVG(salary) AS avg_salary FROM employees GROUP BY department;

-- ============================================
-- 4. MIN: Minimum Value
-- ============================================
SELECT MIN(salary) AS lowest_salary FROM employees;

SELECT MIN(hire_date) AS earliest_hire FROM employees;

SELECT MIN(salary) AS lowest_it_salary FROM employees WHERE department = 'IT';

-- ============================================
-- 5. MAX: Maximum Value
-- ============================================
SELECT MAX(salary) AS highest_salary FROM employees;

SELECT MAX(hire_date) AS latest_hire FROM employees;

SELECT MAX(salary) AS highest_sales_salary FROM employees WHERE department = 'Sales';

-- ============================================
-- 6. COMBINING MULTIPLE AGGREGATES
-- ============================================
SELECT 
    COUNT(*) AS employee_count,
    SUM(salary) AS total_salary,
    AVG(salary) AS average_salary,
    MIN(salary) AS lowest_salary,
    MAX(salary) AS highest_salary
FROM employees;

SELECT 
    COUNT(*) AS it_employees,
    AVG(salary) AS avg_it_salary,
    SUM(salary) AS total_it_salary
FROM employees
WHERE department = 'IT';

-- ============================================
-- 7. AGGREGATE WITH WHERE CLAUSE
-- ============================================
SELECT 
    COUNT(*) AS senior_employees,
    AVG(salary) AS avg_senior_salary
FROM employees
WHERE salary > 70000;

SELECT 
    COUNT(*) AS recent_hires,
    AVG(salary) AS avg_recent_salary
FROM employees
WHERE YEAR(hire_date) >= 2023;

-- ============================================
-- 8. AGGREGATE WITH DISTINCT
-- ============================================
SELECT COUNT(DISTINCT department) AS num_departments FROM employees;

SELECT AVG(DISTINCT salary) AS avg_distinct_salary FROM employees;


SELECT 
    COUNT(*) AS 'Total Employees',
    ROUND(AVG(salary), 2) AS 'Average Salary',
    MIN(salary) AS 'Minimum Salary',
    MAX(salary) AS 'Maximum Salary',
    MAX(salary) - MIN(salary) AS 'Salary Range'
FROM employees;

SELECT 
    COUNT(*) AS 'Employee Count',
    SUM(salary) AS 'Total Payroll',
    ROUND(AVG(salary), 2) AS 'Average Salary'
FROM employees
WHERE department = 'Sales';

SELECT 
    'All Employees' AS department,
    COUNT(*) AS count,
    ROUND(AVG(salary), 2) AS avg_salary
FROM employees;

SELECT 
    ROUND(AVG(salary), 2) AS avg_salary,
    ROUND(SUM(salary), 2) AS total_salary,
    ROUND(MAX(salary), 0) AS max_salary
FROM employees;


SELECT 
    SUM(salary) * 1.1 AS total_with_10pct_raise,
    ROUND(AVG(salary) * 0.05, 2) AS avg_bonus_5pct
FROM employees;
