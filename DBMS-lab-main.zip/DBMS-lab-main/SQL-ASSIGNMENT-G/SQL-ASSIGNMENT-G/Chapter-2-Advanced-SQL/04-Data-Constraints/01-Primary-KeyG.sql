
USE company;

-- ============================================
-- 1. PRIMARY KEY: Single Column (Create Table)
-- ============================================
CREATE TABLE IF NOT EXISTS employees (
    emp_id INT PRIMARY KEY,
    first_name VARCHAR(50),
    last_name VARCHAR(50)
);

CREATE TABLE IF NOT EXISTS departments (
    dept_id INT PRIMARY KEY AUTO_INCREMENT,
    dept_name VARCHAR(50)
);

-- ============================================
-- 2. PRIMARY KEY: Multiple Columns (Composite)
-- ============================================
CREATE TABLE IF NOT EXISTS employee_skills (
    emp_id INT,
    skill_id INT,
    proficiency_level INT,
    PRIMARY KEY (emp_id, skill_id)
);

-- ============================================
-- 3. PRIMARY KEY: Named Constraint
-- ============================================
CREATE TABLE IF NOT EXISTS projects (
    project_id INT,
    project_name VARCHAR(100),
    CONSTRAINT pk_projects PRIMARY KEY (project_id)
);

-- ============================================
-- 4. PRIMARY KEY: AUTO_INCREMENT
-- ============================================
CREATE TABLE IF NOT EXISTS customers (
    customer_id INT PRIMARY KEY AUTO_INCREMENT,
    customer_name VARCHAR(50),
    email VARCHAR(100)
);

INSERT INTO customers (customer_name, email)
VALUES ('Alice', 'alice@example.com');  -- customer_id auto-generated

INSERT INTO customers (customer_name, email)
VALUES ('Bob', 'bob@example.com');      -- customer_id auto-incremented

-- ============================================
-- 5. PRIMARY KEY: Adding to Existing Table
-- ============================================
CREATE TABLE IF NOT EXISTS temp_table (
    id INT,
    name VARCHAR(50)
);

ALTER TABLE temp_table
ADD PRIMARY KEY (id);

-- ============================================
-- 6. PRIMARY KEY: Composite with AUTO_INCREMENT
-- ============================================
-- First column auto-increments
CREATE TABLE IF NOT EXISTS orders (
    order_id INT AUTO_INCREMENT,
    customer_id INT,
    order_date DATE,
    PRIMARY KEY (order_id)
);

-- ============================================
-- 7. PRIMARY KEY: Prevent Duplicates
-- ============================================
INSERT INTO employees (emp_id, first_name, last_name)
VALUES (1, 'Alice', 'Smith');


DESCRIBE employees;
SHOW COLUMNS FROM employees;

SHOW KEYS FROM employees;

-- ============================================
-- 10. PRIMARY KEY: Dropping
-- ============================================
ALTER TABLE temp_table
DROP PRIMARY KEY;

-- ============================================
-- 11. PRACTICAL EXAMPLES
-- ============================================

CREATE TABLE IF NOT EXISTS users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS enrollments (
    student_id INT NOT NULL,
    course_id INT NOT NULL,
    enrollment_date DATE,
    PRIMARY KEY (student_id, course_id)
);

CREATE TABLE IF NOT EXISTS invoice_items (
    invoice_id INT NOT NULL,
    line_item_num INT NOT NULL,
    product_id INT,
    quantity INT,
    unit_price DECIMAL(10,2),
    PRIMARY KEY (invoice_id, line_item_num)
);

-- ============================================
-- 12. AUTO_INCREMENT: Starting Value
-- ============================================
CREATE TABLE IF NOT EXISTS products (
    product_id INT PRIMARY KEY AUTO_INCREMENT,
    product_name VARCHAR(100)
) AUTO_INCREMENT=100;  -- Start from 100

-- ============================================
-- 13. AUTO_INCREMENT: Getting Last Insert ID
-- ============================================
INSERT INTO customers (customer_name, email)
VALUES ('Charlie', 'charlie@example.com');

SELECT LAST_INSERT_ID();

-- ============================================
-- 14. PRIMARY KEY vs UNIQUE
-- ============================================

CREATE TABLE IF NOT EXISTS accounts (
    account_id INT PRIMARY KEY,           -- Primary key
    email VARCHAR(100) UNIQUE,            -- Unique but not primary
    username VARCHAR(50) UNIQUE           -- Another unique field
);

-- ============================================
-- 15. COMPOSITE KEY USAGE
-- ============================================
CREATE TABLE IF NOT EXISTS student_courses (
    student_id INT,
    course_id INT,
    grade CHAR(1),
    PRIMARY KEY (student_id, course_id)
);

INSERT INTO student_courses VALUES (1, 101, 'A');
INSERT INTO student_courses VALUES (1, 102, 'B');  -- Same student, different course
INSERT INTO student_courses VALUES (2, 101, 'A');  -- Different student, same course
