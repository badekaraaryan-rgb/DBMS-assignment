
USE company;

CREATE TABLE IF NOT EXISTS employees (
    emp_id INT PRIMARY KEY,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    email VARCHAR(100),
    salary DECIMAL(10,2),
    department VARCHAR(50),
    hire_date DATE
);

INSERT IGNORE INTO employees VALUES
(1, 'Alice', 'Smith', 'alice@company.com', 90000, 'Management', '2021-01-15'),
(2, 'Bob', 'Johnson', 'bob@company.com', 75000, 'Sales', '2022-03-20'),
(3, 'Charlie', 'Brown', 'charlie@company.com', 70000, 'Sales', '2022-06-10'),
(4, 'Diana', 'Davis', 'diana@company.com', 65000, 'HR', '2023-02-01'),
(5, 'Eve', 'Wilson', 'eve@company.com', 62000, 'IT', '2023-05-12'),
(6, 'Frank', 'Miller', 'frank@company.com', 72000, 'IT', '2023-07-01');

-- ============================================
-- 1. DELETE: Single Row
-- ============================================
DELETE FROM employees
WHERE emp_id = 6;

-- ============================================
-- 2. DELETE: Multiple Rows by Condition
-- ============================================
DELETE FROM employees
WHERE department = 'IT';

DELETE FROM employees
WHERE salary < 65000;

-- ============================================
-- 3. DELETE: With AND Condition
-- ============================================
DELETE FROM employees
WHERE department = 'Sales' AND salary < 70000;

-- ============================================
-- 4. DELETE: With OR Condition
-- ============================================
DELETE FROM employees
WHERE department = 'IT' OR department = 'HR';

-- ============================================
-- 5. DELETE: With IN Clause
-- ============================================
DELETE FROM employees
WHERE emp_id IN (1, 3, 5);

-- Delete employees from multiple departments
DELETE FROM employees
WHERE department IN ('Sales', 'Marketing');

-- ============================================
-- 6. DELETE: With LIKE
-- ============================================
DELETE FROM employees
WHERE first_name LIKE 'A%';

DELETE FROM employees
WHERE email LIKE '%inc.com%';

-- ============================================
-- 7. DELETE: With Subquery
-- ============================================
DELETE FROM employees
WHERE salary < (SELECT AVG(salary) FROM employees);

DELETE FROM employees
WHERE emp_id NOT IN (SELECT emp_id FROM high_performers);

-- ============================================
-- 8. DELETE: Using JOIN (MySQL Syntax)
-- ============================================
CREATE TABLE IF NOT EXISTS departments (
    dept_name VARCHAR(50),
    performance_score INT
);

INSERT INTO departments VALUES
('Sales', 80),
('IT', 95),
('HR', 70);

DELETE e FROM employees e
JOIN departments d ON e.department = d.dept_name
WHERE d.performance_score < 75;



DELETE FROM employees;

TRUNCATE TABLE employees;

-- ============================================
-- 10. DELETE: Archive Before Delete
-- ============================================
CREATE TABLE IF NOT EXISTS employees_archive LIKE employees;

INSERT INTO employees_archive
SELECT * FROM employees
WHERE YEAR(hire_date) < 2022;

DELETE FROM employees
WHERE YEAR(hire_date) < 2022;



DELETE FROM employees
WHERE email LIKE '%test%' OR email LIKE '%temp%';

DELETE FROM employees
WHERE hire_date < DATE_SUB(CURDATE(), INTERVAL 3 YEAR);

DELETE FROM employees
WHERE email IS NULL AND phone IS NULL;

DELETE FROM employees
WHERE emp_id NOT IN (
    SELECT MAX(emp_id) FROM employees
    GROUP BY email
);

-- ============================================
-- 13. DELETE: Safety Practices
-- ============================================
SELECT * FROM employees WHERE department = 'IT';

INSERT INTO employees_archive
SELECT * FROM employees WHERE department = 'IT';

DELETE FROM employees WHERE department = 'IT';

SELECT COUNT(*) FROM employees;

UPDATE employees
SET status = 'Inactive'
WHERE YEAR(CURDATE()) - YEAR(hire_date) > 10;


CREATE TABLE IF NOT EXISTS orders (
    order_id INT PRIMARY KEY,
    emp_id INT,
    amount DECIMAL(10,2),
    FOREIGN KEY (emp_id) REFERENCES employees(emp_id)
);


DELETE FROM orders WHERE emp_id = 1;
DELETE FROM employees WHERE emp_id = 1;

