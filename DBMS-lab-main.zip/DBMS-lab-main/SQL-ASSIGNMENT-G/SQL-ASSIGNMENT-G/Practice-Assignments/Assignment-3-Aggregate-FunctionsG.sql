

USE practice_db;

CREATE TABLE IF NOT EXISTS employees (
    emp_id INT PRIMARY KEY,
    name VARCHAR(50),
    salary DECIMAL(10,2),
    department VARCHAR(50),
    years_employed INT
);

INSERT IGNORE INTO employees VALUES
(1, 'Alice', 90000, 'Sales', 5),
(2, 'Bob', 75000, 'IT', 3),
(3, 'Charlie', 70000, 'Sales', 2),
(4, 'Diana', 65000, 'HR', 1),
(5, 'Eve', 62000, 'IT', 1),
(6, 'Frank', 72000, 'Sales', 4),
(7, 'Grace', 68000, 'Finance', 2),
(8, 'Henry', 80000, 'IT', 6);

